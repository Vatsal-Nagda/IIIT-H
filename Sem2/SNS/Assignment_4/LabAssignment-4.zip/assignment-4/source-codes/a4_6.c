#include<stdio.h>
#include<string.h>

int main(int argc, char *argv[]) {
	char buf[80];

	getchar();
	strcpy(buf, argv[1]);

	return 1;
}
