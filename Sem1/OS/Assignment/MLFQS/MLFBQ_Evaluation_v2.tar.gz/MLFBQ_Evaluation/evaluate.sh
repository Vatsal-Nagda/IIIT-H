#!/bin/bash

# check number of arguments
if [ $# != 3 ]
then
	echo "Agruments(3): code file path, input file path and output file path expected"
	exit 1
fi

#check if the file exists and is readable
if [ ! -r $1 ]
then
	echo "Either $1 does not exists or is not readable"
	exit 1
fi

#check if input file exists and is readable
if [ ! -r $2 ]
then
	echo "Either $2 does not exists or is not readable"
	exit 1
fi

#check if output file exists and is readable
if [ ! -r $3 ]
then
	echo "Either $3 does not exists or is not readable"
	exit 1
fi

#check if file is *.c or *.cpp and assign compiler
if [[ $1 == *.c ]]
then
	COMPILER=gcc
elif [[ $1 == *.cpp ]]
then
	COMPILER=g++
else
	echo "file type can be either .c or .cpp"
	exit 1
fi

#check of COMPILER is installed
$COMPILER -v 2> /dev/null
if [ $? != 0 ]
then
	echo "$COMPILER not found;"
	exit 1
fi

#Compile file
$COMPILER $1 2> /dev/null
if [ $? != 0 ]
then
	echo "Compile time error"
	exit 1
fi

#Execute code
./a.out $2 a.out.txt 2> /dev/null

if [ $? != 0 ]
then
	echo "Runtime error"
	exit 1
fi

#Check diff with actual output
result=`diff a.out.txt $3 | wc -l`

#check result
if [ $result == "0" ]
then
	echo "PASSED"
else
	echo "FAILED"
fi	

#clean up
rm a.out a.out.txt