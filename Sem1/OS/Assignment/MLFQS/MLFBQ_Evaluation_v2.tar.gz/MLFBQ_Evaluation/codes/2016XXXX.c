#include <stdio.h>

int main(int argc, char** argv){
	freopen(argv[2],"w",stdout);
	printf("1 0 44 30\n");
	printf("2 0 31 16\n");
	printf("3 0 41 28\n");
	printf("4 6 34 22\n");
	printf("5 14 35 29\n");
	return 0;
}
