#include <iostream>
#include <cstdio>

using namespace std;

int main (int c, char** argv) {
	freopen(argv[2],"w",stdout);
	cout << "1 0 44 30" << endl;
	cout << "2 0 31 16" << endl;
	cout << "3 0 41 28" << endl;
	cout << "4 6 34 22" << endl;
	cout << "5 14 35 29"<< endl;
	return 0;
}