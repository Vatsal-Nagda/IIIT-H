#!/usr/bin/python

m = '7'
n = 3

try:
	v = m + n
except TypeError, e:
	print type(e)
else:
	print d
	
