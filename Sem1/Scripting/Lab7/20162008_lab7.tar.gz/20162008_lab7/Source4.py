#!/usr/bin/python

try:
	import syst
except ImportError, e:
	print type(e)
else:
	print "imported"
