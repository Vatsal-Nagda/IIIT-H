#!/bin/sh

#RelIdApp_TarBall=$1 
#buildName=$2
RelIdApp_TarBall='MahaSecure.tar.gz'
buildName='MahaSecure'

#echo "Where you want to Extract MahaSecure App?"
#read -p 'Enter Directory Name here? : ' UNIKEN_HOME

UNIKEN_HOME=$HOME"/MahaSecure"
echo $UNIKEN_HOME

mkdir -p $UNIKEN_HOME

if [ $? = "0" ];
then
	echo "Extracting Please wait..........."
	tar -zxvf $RelIdApp_TarBall -C $UNIKEN_HOME/

else
	echo "Exit........."
	exit
fi 

    check="yes"
	if [ $check ];
	then
			
		rm $UNIKEN_HOME/bin/$buildName.sh
		 echo "#!/bin/sh" >> $UNIKEN_HOME/bin/$buildName.sh
		 echo "export LD_LIBRARY_PATH=$UNIKEN_HOME/Shared" >> $UNIKEN_HOME/bin/$buildName.sh
		 echo "cd $UNIKEN_HOME/bin" >> $UNIKEN_HOME/bin/$buildName.sh
		 echo "./$buildName" >> $UNIKEN_HOME/bin/$buildName.sh
		 echo "if [ $? != "0" ];" >> $UNIKEN_HOME/bin/$buildName.sh
		 echo "then" >> $UNIKEN_HOME/bin/$buildName.sh
		 echo "exit" >> $UNIKEN_HOME/bin/$buildName.sh
		 echo "fi" >> $UNIKEN_HOME/bin/$buildName.sh
	
		cd $HOME
		rm Desktop/$buildName.desktop
		 echo "[Desktop Entry]" >> Desktop/$buildName.desktop
		 echo "Version=1.0" >> Desktop/$buildName.desktop
		 echo "Type=Application" >> Desktop/$buildName.desktop
		 echo "Terminal=false" >> Desktop/$buildName.desktop
		 echo "Name[en_IN]=$buildName" >> Desktop/$buildName.desktop
		 echo "Exec=$UNIKEN_HOME/bin/$buildName.sh" >> Desktop/$buildName.desktop
		 echo "Name=$buildName" >> Desktop/$buildName.desktop
		 echo "Icon=$UNIKEN_HOME/Resource/appIcon.png" >> Desktop/$buildName.desktop
		
		 chmod 777 Desktop/$buildName.desktop
		 chmod -R 777 $UNIKEN_HOME
		
		echo "Done........Thanks!!!!!!!!"
	else
		echo "Exit..........."
		exit
	fi


