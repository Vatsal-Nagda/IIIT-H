cat varLength1 | grep -E ".{5,}"
