 sed -E "s/\<iit\>/IIIT beats iit/g" collegeBattles.txt
