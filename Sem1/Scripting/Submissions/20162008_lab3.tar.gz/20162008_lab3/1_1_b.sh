 cat /usr/share/dict/words | grep -E "^([aeiouAEIOU]).{3}[^aeiouAEIOU]$"
