 sed -E 's/(Batman)( and )(Superman)/\3\2\1/g' replaceConsecutive.txt
