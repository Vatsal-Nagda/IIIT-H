cat varLength2 | grep -E ".{12,20}"
