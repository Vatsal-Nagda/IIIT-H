cat /usr/share/dict/words | grep -E "(^([aeiouAEIOU])...[aeiouAEIOU]$)|(^.{,2}$)
