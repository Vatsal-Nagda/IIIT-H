 cat /usr/share/dict/words | grep -E "^([a-zA-Z])([a-zA-Z]).*\2\1$"
