cat varLength3 | grep -E ".{7}"
