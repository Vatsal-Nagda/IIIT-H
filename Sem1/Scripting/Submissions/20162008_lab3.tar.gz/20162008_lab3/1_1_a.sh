cat /usr/share/dict/words | grep -E "^[a-zA-Z].{2}$"
