grep  -ls "world" ./* ./*/*/*
