grep -c -r -E "manager"
