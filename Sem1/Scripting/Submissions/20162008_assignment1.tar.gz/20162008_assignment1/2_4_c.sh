find ./ ./*/*/* -maxdepth 1 -mindepth 1 -type f
