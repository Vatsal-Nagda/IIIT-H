 sort -n Items.txt -o Items.txt
