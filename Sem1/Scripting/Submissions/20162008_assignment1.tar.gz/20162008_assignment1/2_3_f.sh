grep -E -ls -v "pappu" ./*/* ./*/*/*
