grep -E "(+91)?-?[0-9]{10}$" phone
