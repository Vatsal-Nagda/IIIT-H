ls -l |  sort -r | grep "Sep  4"
