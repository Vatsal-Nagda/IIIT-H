cp -n -u -r ./dir1/* dir2
