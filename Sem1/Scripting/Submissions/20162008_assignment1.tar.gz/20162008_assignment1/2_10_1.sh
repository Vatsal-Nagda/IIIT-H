grep -E "^.{5,}" emp.lst
