more salaries |tr '|' ' ' | tr -s ' ' |grep -E "^s[a-zA-Z]* 7[0-9]{3}$"
