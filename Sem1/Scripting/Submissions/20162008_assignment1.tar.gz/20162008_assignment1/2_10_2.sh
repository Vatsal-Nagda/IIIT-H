grep -E "^.{12,20}$" emp.lst
