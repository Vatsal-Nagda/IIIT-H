man echo > echo.txt
    split echo.txt --suffix-length=2 --numeric-suffixes=3 -n 15
