 ls -i | sort -r | grep "^[0-9]*[02468] "| cut -d" " -f2| tr '\n' '
 '
