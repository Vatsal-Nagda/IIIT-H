find -maxdepth 10 -mindepth 10 -type f
