find -maxdepth 3 -mindepth 3 -type f
