ls -il |sed '1 d' |cut -d" " -f1 > inode.txt
