grep -E -v '^[ ]*$' input
