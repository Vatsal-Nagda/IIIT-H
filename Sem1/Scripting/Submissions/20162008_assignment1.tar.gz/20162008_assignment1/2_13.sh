grep -c -r -E -e "teacher" -e "student"
