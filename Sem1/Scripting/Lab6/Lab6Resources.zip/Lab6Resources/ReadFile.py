#!/bin/python

f=open("speed.txt")

for line in f:
	print line