#include <stdio.h>
void sort(int [],int);

int main(){
	int i,j,t,n;
	scanf("%d",&t);

	int arr[1000000];

	for(i=0;i<t;i++){
		scanf("%d",&n);

	sort(arr,n);

		for(j=0;j<n;j++){
			if(arr[j]== arr[j+1] && arr[j+1]== arr[j+2])
				j+=2;
			else{
				printf("%d",arr[j]);
				break;
			}
		}
	}

	return 0;
}

void sort(int arr[],int size){
	int i,j,temp,pos,min;

	for(i=0;i<size;i++){
		min = arr[i];
		pos = i;
		
		for(j=i+1;j<size;j++){
			if(arr[j] < min){
				min = arr[j];
				pos = j;
			}
		}

		if(pos != i){
			temp = arr[pos];
			arr[pos] = arr[i];
			arr[i] = temp;
		}
	}
}