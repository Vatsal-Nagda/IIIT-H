#include <stdio.h>

int main(){
	int i,j,n,count;
	scanf("%d",&n);
	//int flag = 0;

	//char stack[1000000]={''};
	char str[1000000];
	char temp;

	for(i=0;i<n;i++){
		count=0;
	scanf("%s",str);
		j=0;
		temp = str[j];

		while(temp != '\n'){
		
			if(temp == '(')
				count++;
			else if(temp == ')'){
				count--;
				if (count == -1){
					break;
				}
			}	
			j++;		
			temp = str[j];
		}

		if(count == 0)
			printf("YES\n");
		else
			printf("NO\n");
	}

	return 0;
}