#include <stdio.h>

int main(){
	unsigned int s,e,N;
	scanf("%d%d%d",&s,&e,&N);
	int i;
	int S[1000002]={0};
	int E[1000002]={0};

	for(i=1;i<N+1;i++){
		scanf("%d%d",&S[i],&E[i]);
		if(S[i] >= s && S[i-1 <=s]){
			S[i+1] = S[i];
			E[i+1] = E[i];
			S[i] = s;
			E[i] = e;
			i++;
		}
	}

	int des=E[1];
	int count=0;
	for(i=1;i<N+1;i++){
		if(S[i] >= des){
			count++;
			//des = E[i];
		}
		if(E[i] > des)
			des = E[i];
		
	}

	/*for(i=0;i<N+1;i++){
		printf("S: %d,  D: %d\n",S[i],E[i]);		
	}*/
		printf("%d\n",count);


	return 0;
}